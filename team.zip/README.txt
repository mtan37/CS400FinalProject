README


Course: cs400

Semester: Spring 2019

Project name: Practice Quiz Generator

Team number: ATeam-25

Team Members:


Marvin Tan, 002, A-25, marvin.tan@wisc.edu

Nate Sackett, 004, A-25, nsackett@wisc.edu

Shao Bin Daniel Shi Hong, 004, A-25, shong78@wisc.edu

Hui Beom Kim, 004, A-25, hkim788@wisc.edu

Zhengyi Chen, 004, A-25, zchen597@wisc.edu


Instructions: Thanks for using our QuizGenerator!!
Note: Before generating any quiz,User should have loaded/created at least one question. 

ADD QUESTION: CLICK "Add question" button.
               |
              (1)-------> Load Question: CLICK "Load Question From File": select file you want to load into the quizGenerator in your system.
              (2)-------> Create Question: CLICK "Create New Questions": 1.specify the topic of the Question 2. Describing the Question
           								 3.Add image(optional), if not the default image will be set.
 									 4.Add at least two choices 5.choose correct answer, CLICK Finish.

GENERATE QUIZ: CLICK "Generate a New Quiz" button. (make sure there exist at least one question )
 		|
	       (1)-------> Select topics of the quiz you want to generate.
  	       (2)-------> Specify the number of questions the quiz should contain, if the user requests more than storage,
                                 QuizGenerator would consume all its questions to generate a quiz.

CHECK QUESTION DATABASE: CLICK "Check Loaded Question Database" button.
                    	  |
			 (1)-------> All topics and associated number of questions would be displayed
                         (2)-------> SAVE FILE: CLICK "Check Loaded Question Bank" Button.
						 |
						 --------> All questions in the Database will be written into a Jason File.

Exit the Program: Directly exit program, questions in the database will lost without saving.
		
